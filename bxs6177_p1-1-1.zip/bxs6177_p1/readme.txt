to run:
python tfnew.py